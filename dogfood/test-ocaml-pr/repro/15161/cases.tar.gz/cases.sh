#!/bin/bash
# cases.sh SRC OUT [extra ocamlopt flags...]
# Compiles every case with SRC's ocamlc.opt (bytecode, run by SRC's ocamlrun)
# and ocamlopt.opt, runs each (multi-case programs one case per process) and
# writes OUT/byte.txt, OUT/nat.txt: one line per case "id<TAB>output rc=N".
SRC=$1; OUT=$2; shift 2; NATFLAGS="$*"
C=$(cd "$(dirname "$0")" && pwd)
mkdir -p "$OUT"
for mode in byte nat; do
  : > "$OUT/$mode.txt"
  for f in adv adv2 probe array_indexing_offset array_indexing_tagged checkbound_const_index; do
    d=$OUT/$mode-$f; mkdir -p "$d"; cp "$C/$f.ml" "$d/"
    if [ $mode = byte ]; then
      ( cd "$d" && "$SRC/ocamlc.opt" -nostdlib -I "$SRC/stdlib" $f.ml -o a.out ) > "$d/build.log" 2>&1
      run=("$SRC/runtime/ocamlrun" "$d/a.out")
    else
      ( cd "$d" && "$SRC/ocamlopt.opt" -nostdlib -I "$SRC/stdlib" -I "$SRC/runtime" $NATFLAGS $f.ml -o a.out ) > "$d/build.log" 2>&1
      run=("$d/a.out")
    fi
    [ -x "$d/a.out" ] || { echo "$f	BUILD FAILED" >> "$OUT/$mode.txt"; continue; }
    if [ $f = adv ] || [ $f = adv2 ] || [ $f = probe ]; then
      n=$("${run[@]}")
      for ((i=0;i<n;i++)); do
        r=$(timeout 10 "${run[@]}" $i 2>&1); rc=$?
        printf '%s:%02d\t%s rc=%d\n' $f $i "$(echo "$r" | tr '\n' ' ' | sed 's/ $//')" $rc >> "$OUT/$mode.txt"
      done
    else
      r=$(timeout 10 "${run[@]}" 2>&1); rc=$?
      printf '%s\t%s rc=%d\n' $f "$(echo "$r" | tr '\n' '|' | sed 's/|$//')" $rc >> "$OUT/$mode.txt"
    fi
  done
done
# summary: cases where native differs from bytecode
paste -d'\n' "$OUT/byte.txt" "$OUT/nat.txt" | paste - - | awk -F'\t' '$2 != $4 {print "DIFF " $1 "\n   byte: " $2 "\n   nat:  " $4}' > "$OUT/diff.txt"
echo "$(wc -l < "$OUT/byte.txt") cases, $(grep -c '^DIFF' "$OUT/diff.txt") native/bytecode differences"
