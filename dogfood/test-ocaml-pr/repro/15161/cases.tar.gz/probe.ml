(* Probes for the two #15161 test cases: print what is actually read or
   written (one case per process: `probe N`; no argument = number of cases). *)
open Bigarray
let index = Int64.add Int64.min_int 5L
let k = 0x1000_0000_0000_0000
let i = k + 1
let[@inline never] get_char (b : (char, int8_unsigned_elt, c_layout) Array1.t) x = Array1.unsafe_get b (Int64.to_int x)
let[@inline never] get_int8 (b : (int, int8_signed_elt, c_layout) Array1.t) x = Array1.unsafe_get b (Int64.to_int x)
let[@inline never] get_uint8 (b : (int, int8_unsigned_elt, c_layout) Array1.t) x = Array1.unsafe_get b (Int64.to_int x)
let[@inline never] set_char (b : (char, int8_unsigned_elt, c_layout) Array1.t) x v = Array1.unsafe_set b (Int64.to_int x) v
let[@inline never] o_get_int (a : int array) i = Array.unsafe_get a (i - k)
let[@inline never] o_get_float (a : float array) i = Array.unsafe_get a (i - k)
let[@inline never] o_set_int (a : int array) i v = Array.unsafe_set a (i - k) v
let[@inline never] o_get_f64 (b : (float, float64_elt, c_layout) Array1.t) i = Array1.unsafe_get b (i - k)
let chars () = Array1.of_array char c_layout [| 'a'; 'b'; 'c'; 'd'; 'e'; 'f' |]
let show_chars b = String.init (Array1.dim b) (Array1.get b)
let cases = [|
  "tagged char get (want f)", (fun () -> String.make 1 (get_char (chars ()) index));
  "tagged int8 get (want -5)", (fun () -> string_of_int (get_int8 (Array1.of_array int8_signed c_layout [|0;-1;-2;-3;-4;-5|]) index));
  "tagged uint8 get (want 5)", (fun () -> string_of_int (get_uint8 (Array1.of_array int8_unsigned c_layout [|0;1;2;3;4;5|]) index));
  "tagged char set (want abcdez)", (fun () -> let b = chars () in set_char b index 'z'; show_chars b);
  "offset int get (want 11)", (fun () -> string_of_int (o_get_int [|10;11;12|] i));
  "offset float get (want 2.)", (fun () -> string_of_float (o_get_float [|1.;2.;3.|] i));
  "offset int set (want 10,42,12)", (fun () -> let a = [|10;11;12|] in o_set_int a i 42; String.concat "," (List.map string_of_int (Array.to_list a)));
  "offset float64 bigarray get (want 2.)", (fun () -> string_of_float (o_get_f64 (Array1.of_array float64 c_layout [|1.;2.;3.|]) i));
|]
let () =
  if Array.length Sys.argv < 2 then print_int (Array.length cases)
  else let n, f = cases.(int_of_string Sys.argv.(1)) in
    Printf.printf "%s: %s\n%!" n (f ())
