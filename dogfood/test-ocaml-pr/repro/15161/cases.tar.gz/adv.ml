(* adversarial array-indexing cases; run as `adv N` (one case per process) *)
open Bigarray
let k60 = 0x1000_0000_0000_0000 (* 2^60 *)
let k59p = 0x0800_0000_0000_0001 (* 2^59 + 1 *)
let k59m = 0x07ff_ffff_ffff_ffff (* 2^59 - 1 = max_int / 8 *)
let kmax = max_int - 1
let o x = Sys.opaque_identity x
let[@inline never] g_off60 (a : int array) i = a.(i - k60)
let[@inline never] u_off60 (a : int array) i = Array.unsafe_get a (i - k60)
let[@inline never] s_off60 (a : int array) i v = a.(i - k60) <- v
let[@inline never] f_off60 (a : float array) i = a.(i - k60)
let[@inline never] g_off59p (a : int array) i = a.(i - k59p)
let[@inline never] g_off59m (a : int array) i = a.(i - k59m)
let[@inline never] g_offmax (a : int array) i = a.(i - kmax)
let[@inline never] g_offneg (a : int array) i = a.(i + k60)
let[@inline never] g_offmin (a : int array) i = a.(i + min_int)
let[@inline never] b32_off (b : (int32, int32_elt, c_layout) Array1.t) i = Array1.get b (i - kmax)
let[@inline never] b16_off (b : (int, int16_signed_elt, c_layout) Array1.t) i = Array1.get b (i - kmax)
let[@inline never] b64_off60 (b : (float, float64_elt, c_layout) Array1.t) i = Array1.get b (i - k60)
let idx64 = Int64.add Int64.min_int 5L
let[@inline never] ch_get (b : (char, int8_unsigned_elt, c_layout) Array1.t) x = Array1.get b (Int64.to_int x)
let[@inline never] ch_uget (b : (char, int8_unsigned_elt, c_layout) Array1.t) x = Array1.unsafe_get b (Int64.to_int x)
let[@inline never] i8_get (b : (int, int8_signed_elt, c_layout) Array1.t) x = Array1.get b (Int64.to_int x)
let[@inline never] i16_get (b : (int, int16_signed_elt, c_layout) Array1.t) x = Array1.get b (Int64.to_int x)
let[@inline never] by_get (b : Bytes.t) x = Bytes.get b (Int64.to_int x)
let[@inline never] st_get (s : string) x = String.get s (Int64.to_int x)
let[@inline never] ar_get (a : int array) x = a.(Int64.to_int x)
(* constant indices on a parameter (stock make_checkbound) *)
let[@inline never] c54 (a : int array) = a.(0x40_0000_0000_0001)
let[@inline never] c54f (a : float array) = a.(0x40_0000_0000_0001)
let[@inline never] c52 (a : int array) = a.(0x10_0000_0000_0001)
let[@inline never] cmax (a : int array) = a.(max_int)
let[@inline never] cmin (a : int array) = a.(min_int)
let[@inline never] cm1 (a : int array) = a.(-1)
let[@inline never] cmax8 (a : int array) = a.(max_int / 8)
(* constant indices on a local array of known length (wp_bounds' folded check) *)
let[@inline never] l54 n = let a = Array.make (o 4) n in a.(0x40_0000_0000_0001)
let[@inline never] l54c n = let a = Array.make 4 n in a.(0x40_0000_0000_0001)
let[@inline never] l54f n = let a = Array.make 4 (float n) in a.(0x40_0000_0000_0001)
let[@inline never] l3_54 n = let a = Array.make 4 n in a.(3) + a.(0x40_0000_0000_0001)
let[@inline never] l54_3 n = let a = Array.make 4 n in a.(0x40_0000_0000_0001) + a.(3)
let[@inline never] l3_m1 n = let a = Array.make 4 n in a.(3) + a.(-1)
let[@inline never] l3_min n = let a = Array.make 4 n in a.(3) + a.(min_int)
let[@inline never] l3_max n = let a = Array.make 4 n in a.(3) + a.(max_int)
let[@inline never] lmax_3 n = let a = Array.make 4 n in a.(max_int) + a.(3)
let[@inline never] l3_4 n = let a = Array.make 4 n in a.(3) + a.(4)
let[@inline never] l3_52 n = let a = Array.make 4 n in a.(3) + a.(0x10_0000_0000_0001)
let[@inline never] l3_53 n = let a = Array.make 4 n in a.(3) + a.(0x20_0000_0000_0001)
let[@inline never] lit_54 n = let a = [| n; n; n; n |] in a.(0x40_0000_0000_0001)
let[@inline never] lvar_54 n m = let a = Array.make m n in a.(2) + a.(0x40_0000_0000_0001)
let[@inline never] u_off59p (a : int array) i = Array.unsafe_get a (i - k59p)
let[@inline never] u_off59m (a : int array) i = Array.unsafe_get a (i - k59m)
let[@inline never] u_offmax (a : int array) i = Array.unsafe_get a (i - kmax)
let[@inline never] u_offneg (a : int array) i = Array.unsafe_get a (i + k60)
let[@inline never] u_offmin (a : int array) i = Array.unsafe_get a (i + min_int)
let[@inline never] uf_off60 (a : float array) i = Array.unsafe_get a (i - k60)
let[@inline never] ub32_offmax (b : (int32, int32_elt, c_layout) Array1.t) i = Array1.unsafe_get b (i - kmax)
let[@inline never] ub32_off60 (b : (int32, int32_elt, c_layout) Array1.t) i = Array1.unsafe_get b (i - k60)
let[@inline never] ub32_off61 (b : (int32, int32_elt, c_layout) Array1.t) i = Array1.unsafe_get b (i - 0x2000_0000_0000_0001)
let[@inline never] ub16_offmax (b : (int, int16_signed_elt, c_layout) Array1.t) i = Array1.unsafe_get b (i - kmax)
let[@inline never] ub64_off60 (b : (float, float64_elt, c_layout) Array1.t) i = Array1.unsafe_get b (i - k60)
let[@inline never] ui16_get (b : (int, int16_signed_elt, c_layout) Array1.t) x = Array1.unsafe_get b (Int64.to_int x)
let[@inline never] ui8_get (b : (int, int8_signed_elt, c_layout) Array1.t) x = Array1.unsafe_get b (Int64.to_int x)
let[@inline never] uby_get (b : Bytes.t) x = Bytes.unsafe_get b (Int64.to_int x)
let cases : (string * (unit -> string)) array = [|
  "g_off60", (fun () -> string_of_int (g_off60 [|10;11;12|] (o (k60 + 1))));
  "u_off60", (fun () -> string_of_int (u_off60 [|10;11;12|] (o (k60 + 1))));
  "s_off60", (fun () -> let a = [|10;11;12|] in s_off60 a (o (k60 + 1)) 42; string_of_int a.(1));
  "f_off60", (fun () -> string_of_float (f_off60 [|1.;2.;3.|] (o (k60 + 1))));
  "g_off59p", (fun () -> string_of_int (g_off59p [|10;11;12|] (o (k59p + 1))));
  "g_off59m", (fun () -> string_of_int (g_off59m [|10;11;12|] (o (k59m + 1))));
  "g_offmax", (fun () -> string_of_int (g_offmax [|10;11;12|] (o (kmax + 1))));
  "g_offneg", (fun () -> string_of_int (g_offneg [|10;11;12|] (o (1 - k60))));
  "g_offmin", (fun () -> string_of_int (g_offmin [|10;11;12|] (o (1 - min_int))));
  "b32_off", (fun () -> Int32.to_string (b32_off (Array1.of_array int32 c_layout [|1l;2l;3l|]) (o (kmax + 1))));
  "b16_off", (fun () -> string_of_int (b16_off (Array1.of_array int16_signed c_layout [|1;2;3|]) (o (kmax + 1))));
  "b64_off60", (fun () -> string_of_float (b64_off60 (Array1.of_array float64 c_layout [|1.;2.;3.|]) (o (k60 + 1))));
  "ch_get", (fun () -> String.make 1 (ch_get (Array1.of_array char c_layout [|'a';'b';'c';'d';'e';'f'|]) (o idx64)));
  "ch_uget", (fun () -> String.make 1 (ch_uget (Array1.of_array char c_layout [|'a';'b';'c';'d';'e';'f'|]) (o idx64)));
  "i8_get", (fun () -> string_of_int (i8_get (Array1.of_array int8_signed c_layout [|0;-1;-2;-3;-4;-5|]) (o idx64)));
  "i16_get", (fun () -> string_of_int (i16_get (Array1.of_array int16_signed c_layout [|0;-1;-2;-3;-4;-5|]) (o idx64)));
  "by_get", (fun () -> String.make 1 (by_get (Bytes.of_string "abcdef") (o idx64)));
  "st_get", (fun () -> String.make 1 (st_get (o "abcdef") (o idx64)));
  "ar_get", (fun () -> string_of_int (ar_get [|0;1;2;3;4;5|] (o idx64)));
  "c54", (fun () -> string_of_int (c54 (Array.make 4 0)));
  "c54f", (fun () -> string_of_float (c54f (Array.make 4 0.)));
  "c52", (fun () -> string_of_int (c52 (Array.make 4 0)));
  "cmax", (fun () -> string_of_int (cmax (Array.make 4 0)));
  "cmin", (fun () -> string_of_int (cmin (Array.make 4 0)));
  "cm1", (fun () -> string_of_int (cm1 (Array.make 4 0)));
  "cmax8", (fun () -> string_of_int (cmax8 (Array.make 4 0)));
  "l54", (fun () -> string_of_int (l54 (o 7)));
  "l54c", (fun () -> string_of_int (l54c (o 7)));
  "l54f", (fun () -> string_of_float (l54f (o 7)));
  "l3_54", (fun () -> string_of_int (l3_54 (o 7)));
  "l54_3", (fun () -> string_of_int (l54_3 (o 7)));
  "l3_m1", (fun () -> string_of_int (l3_m1 (o 7)));
  "l3_min", (fun () -> string_of_int (l3_min (o 7)));
  "l3_max", (fun () -> string_of_int (l3_max (o 7)));
  "lmax_3", (fun () -> string_of_int (lmax_3 (o 7)));
  "l3_4", (fun () -> string_of_int (l3_4 (o 7)));
  "l3_52", (fun () -> string_of_int (l3_52 (o 7)));
  "l3_53", (fun () -> string_of_int (l3_53 (o 7)));
  "lit_54", (fun () -> string_of_int (lit_54 (o 7)));
  "lvar_54", (fun () -> string_of_int (lvar_54 (o 7) (o 4)));
  "u_off59p", (fun () -> string_of_int (u_off59p [|10;11;12|] (o (k59p + 1))));
  "u_off59m", (fun () -> string_of_int (u_off59m [|10;11;12|] (o (k59m + 1))));
  "u_offmax", (fun () -> string_of_int (u_offmax [|10;11;12|] (o (kmax + 1))));
  "u_offneg", (fun () -> string_of_int (u_offneg [|10;11;12|] (o (1 - k60))));
  "u_offmin", (fun () -> string_of_int (u_offmin [|10;11;12|] (o (1 - min_int))));
  "uf_off60", (fun () -> string_of_float (uf_off60 [|1.;2.;3.|] (o (k60 + 1))));
  "ub32_offmax", (fun () -> Int32.to_string (ub32_offmax (Array1.of_array int32 c_layout [|1l;2l;3l|]) (o (kmax + 1))));
  "ub32_off60", (fun () -> Int32.to_string (ub32_off60 (Array1.of_array int32 c_layout [|1l;2l;3l|]) (o (k60 + 1))));
  "ub32_off61", (fun () -> Int32.to_string (ub32_off61 (Array1.of_array int32 c_layout [|1l;2l;3l|]) (o (0x2000_0000_0000_0002))));
  "ub16_offmax", (fun () -> string_of_int (ub16_offmax (Array1.of_array int16_signed c_layout [|1;2;3|]) (o (kmax + 1))));
  "ub64_off60", (fun () -> string_of_float (ub64_off60 (Array1.of_array float64 c_layout [|1.;2.;3.|]) (o (k60 + 1))));
  "ui16_get", (fun () -> string_of_int (ui16_get (Array1.of_array int16_signed c_layout [|0;-1;-2;-3;-4;-5|]) (o idx64)));
  "ui8_get", (fun () -> string_of_int (ui8_get (Array1.of_array int8_signed c_layout [|0;-1;-2;-3;-4;-5|]) (o idx64)));
  "uby_get", (fun () -> String.make 1 (uby_get (Bytes.of_string "abcdef") (o idx64)));
|]
let () =
  if Array.length Sys.argv < 2 then print_int (Array.length cases)
  else begin
    let name, f = cases.(int_of_string Sys.argv.(1)) in
    let r = try f () with Invalid_argument m -> "Invalid_argument " ^ m in
    Printf.printf "%s: %s\n%!" name r
  end
