(* extra 1-byte-element cases: index = i + constant where the sum wraps in 63 bits
   (Cmm_helpers.array_indexing, case [Caddi [c; Cconst_int n]] when log2size = 0) *)
open Bigarray
let o x = Sys.opaque_identity x
let k60 = 0x1000_0000_0000_0000
let[@inline never] by_min (b : Bytes.t) i = Bytes.get b (i + min_int)
let[@inline never] uby_min (b : Bytes.t) i = Bytes.unsafe_get b (i + min_int)
let[@inline never] st_min (s : string) i = String.get s (i + min_int)
let[@inline never] by_max (b : Bytes.t) i = Bytes.get b (i - max_int)
let[@inline never] uby_max (b : Bytes.t) i = Bytes.unsafe_get b (i - max_int)
let[@inline never] by_pmax (b : Bytes.t) i = Bytes.get b (i + max_int)
let[@inline never] uby_k60 (b : Bytes.t) i = Bytes.unsafe_get b (i - k60)
let[@inline never] ch_min (b : (char, int8_unsigned_elt, c_layout) Array1.t) i = Array1.get b (i + min_int)
let[@inline never] uch_min (b : (char, int8_unsigned_elt, c_layout) Array1.t) i = Array1.unsafe_get b (i + min_int)
let[@inline never] sby_min (b : Bytes.t) i = Bytes.set b (i + min_int) 'z'
let[@inline never] ar_min (a : int array) i = a.(i + min_int)
let[@inline never] b16_min (b : (int, int16_signed_elt, c_layout) Array1.t) i = Array1.get b (i + min_int)
let s () = Bytes.of_string "abcdef"
let cases = [|
  "by_min", (fun () -> String.make 1 (by_min (s ()) (o min_int)));
  "uby_min", (fun () -> String.make 1 (uby_min (s ()) (o min_int)));
  "st_min", (fun () -> String.make 1 (st_min (o "abcdef") (o (min_int + 2))));
  "by_max", (fun () -> String.make 1 (by_max (s ()) (o (min_int + 2))));
  "uby_max", (fun () -> String.make 1 (uby_max (s ()) (o (min_int + 2))));
  "by_pmax", (fun () -> String.make 1 (by_pmax (s ()) (o (min_int + 3))));
  "uby_k60", (fun () -> String.make 1 (uby_k60 (s ()) (o (k60 + 3))));
  "ch_min", (fun () -> String.make 1 (ch_min (Array1.of_array char c_layout [|'a';'b';'c'|]) (o (min_int + 1))));
  "uch_min", (fun () -> String.make 1 (uch_min (Array1.of_array char c_layout [|'a';'b';'c'|]) (o (min_int + 1))));
  "sby_min", (fun () -> let b = s () in sby_min b (o (min_int + 1)); Bytes.to_string b);
  "ar_min", (fun () -> string_of_int (ar_min [|10;11;12|] (o (min_int + 1))));
  "b16_min", (fun () -> string_of_int (b16_min (Array1.of_array int16_signed c_layout [|1;2;3|]) (o (min_int + 1))));
|]
let () =
  if Array.length Sys.argv < 2 then print_int (Array.length cases)
  else begin
    let name, f = cases.(int_of_string Sys.argv.(1)) in
    let r = try f () with Invalid_argument m -> "Invalid_argument " ^ m in
    Printf.printf "%s: %s\n%!" name r
  end
